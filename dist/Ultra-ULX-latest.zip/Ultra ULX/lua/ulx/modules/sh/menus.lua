local L = ULib.ulx_lang
local CATEGORY_NAME = "cat_menu"
if ULib.fileExists( "lua/ulx/modules/cl/motdmenu.lua" ) or ulx.motdmenu_exists then
	local function sendMotd( ply, showMotd )
		if showMotd == "1" then
			if not ULib.fileExists( GetConVarString( "ulx_motdfile" ) ) then return end
			local f = ULib.fileRead( GetConVarString( "ulx_motdfile" ) )
			ULib.clientRPC( ply, "ulx.rcvMotd", showMotd, f )
		elseif showMotd == "2" then
			ulx.populateMotdData()
			ULib.clientRPC( ply, "ulx.rcvMotd", showMotd, ulx.motdSettings )
		else
			ULib.clientRPC( ply, "ulx.rcvMotd", showMotd, GetConVarString( "ulx_motdurl" ) )
		end
	end
	local function showMotd( ply )
		local showMotd = GetConVarString( "ulx_showMotd" )
		if showMotd == "0" then return end
		if not ply:IsValid() then return end
		sendMotd( ply, showMotd )
		ULib.clientRPC( ply, "ulx.showMotdMenu", ply:SteamID() )
	end
	hook.Add( "PlayerInitialSpawn", "showMotd", showMotd )
	function ulx.motdUpdated()
		for _, ply in ipairs( player.GetAll() ) do
			ply.ulxHasMotd = false
		end
	end
	local function conVarUpdated( sv_cvar, cl_cvar, ply, old_val, new_val )
		if string.lower( cl_cvar ) == "ulx_showmotd" or string.lower( cl_cvar ) == "ulx_motdfile" or string.lower( cl_cvar ) == "ulx_motdurl" then
			ulx.motdUpdated()
		end
	end
	hook.Add( "ULibReplicatedCvarChanged", "ulx.clearMotdCache", conVarUpdated )
	function ulx.motd( calling_ply )
		if not calling_ply:IsValid() then
			Msg( "无法从控制台查看 MOTD。\n" )
			return
		end
		if GetConVarString( "ulx_showMotd" ) == "0" then
			if GetConVarString( "ulx_motdDisabledMessage" ) == "1" then
				ULib.tsay( calling_ply, L.T("menu_motd_disabled") )
			end
			return
		end
		if GetConVarString( "ulx_showMotd" ) == "1" and not ULib.fileExists( GetConVarString( "ulx_motdfile" ) ) then
			ULib.tsay( calling_ply, L.T("menu_motd_missing") )
			return
		end
		showMotd( calling_ply )
	end
	local motdmenu = ulx.command( CATEGORY_NAME, "ulx motd", ulx.motd, "!motd" )
	motdmenu:defaultAccess( ULib.ACCESS_ALL )
	motdmenu:help( L.T("help_motd") )
	if SERVER then
		ulx.convar( "showMotd", "2", " <0/1/2/3> - MOTD mode. 0 is off.", ULib.ACCESS_ADMIN )
		ulx.convar( "motdfile", "ulx_motd.txt", "MOTD filepath from gmod root to use if ulx showMotd is 1.", ULib.ACCESS_ADMIN )
		ulx.convar( "motdurl", "ulyssesmod.net", "MOTD URL to use if ulx showMotd is 3.", ULib.ACCESS_ADMIN )
		ulx.convar( "motdDisabledMessage", "1", "<0/1> - Show disabled message when MOTD command is run if MOTD is disabled by the server. 0 is off.", ULib.ACCESS_ADMIN )
		function ulx.populateMotdData()
			if ulx.motdSettings == nil or ulx.motdSettings.info == nil then return end
			ulx.motdSettings.admins = {}
			local getAddonInfo = false
			for i=1, #ulx.motdSettings.info do
				local sectionInfo = ulx.motdSettings.info[i]
				if sectionInfo.type == "mods" then
					getAddonInfo = true
				elseif sectionInfo.type == "admins" then
					for a=1, #sectionInfo.contents do
						ulx.motdSettings.admins[sectionInfo.contents[a]] = true
					end
				end
			end
			if getAddonInfo then
				ulx.motdSettings.addons = {}
				local addons = engine.GetAddons()
				for i=1, #addons do
					local addon = addons[i]
					if addon.mounted then
						table.insert( ulx.motdSettings.addons, { title=addon.title, workshop_id=addon.file:gsub("%D", "") } )
					end
				end
				local _, possibleaddons = file.Find( "addons/*", "GAME" )
				for _, addon in ipairs( possibleaddons ) do
					local name, author = nil, nil
					if ULib.fileExists( "addons/" .. addon .. "/addon.json" ) then
						local js = ULib.fileRead( "addons/" .. addon .. "/addon.json" )
						if js then
							local t = util.JSONToTable( js )
							if t then name, author = t.title, t.author end
						end
					end
					if not name and ULib.fileExists( "addons/" .. addon .. "/addon.txt" ) then
						local t = ULib.parseKeyValues( ULib.stripComments( ULib.fileRead( "addons/" .. addon .. "/addon.txt" ), "//" ) )
						if t and t.AddonInfo then name, author = t.AddonInfo.name, t.AddonInfo.author_name end
					end
					if name then
						table.insert( ulx.motdSettings.addons, { title=name, author=author } )
					end
				end
				local _, gamemodes = file.Find( "gamemodes/*", "GAME" )
				for _, gm in ipairs( gamemodes ) do
					local gmPath = "gamemodes/" .. gm
					if ULib.fileExists( gmPath .. "/addon.txt" ) then
						local t = ULib.parseKeyValues( ULib.stripComments( ULib.fileRead( gmPath .. "/addon.txt" ), "//" ) )
						if t and t.AddonInfo then
							local name = t.AddonInfo.name or gm
							if gm ~= "base" and gm ~= "sandbox" and gm ~= "terrortown" then
								table.insert( ulx.motdSettings.addons, { title=name, author=t.AddonInfo.author_name } )
							end
						end
					end
				end
				table.sort( ulx.motdSettings.addons, function(a,b) return string.lower(a.title) < string.lower(b.title) end )
			end
			for group, _ in pairs( ulx.motdSettings.admins ) do
				ulx.motdSettings.admins[group] = {}
				local seen = {}
				for steamID, data in pairs( ULib.ucl.users ) do
					if data.group == group and data.name and not seen[data.name:lower()] then
						seen[data.name:lower()] = true
						table.insert( ulx.motdSettings.admins[group], data.name )
					end
				end
				for _, ply in ipairs( player.GetAll() ) do
					if ply:CheckGroup( group ) and ply:Nick() and not seen[ply:Nick():lower()] then
						seen[ply:Nick():lower()] = true
						table.insert( ulx.motdSettings.admins[group], ply:Nick() )
					end
				end
			end
		end
		hook.Add( ULib.HOOK_UCLCHANGED, "ulx.updateMotd.adminsChanged", ulx.populateMotdData )
	end
end