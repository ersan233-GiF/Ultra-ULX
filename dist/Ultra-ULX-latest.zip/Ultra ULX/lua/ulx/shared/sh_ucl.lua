ULib.ucl = ULib.ucl or {}
local ucl = ULib.ucl
ucl.groups = ucl.groups or {}
ucl.users = ucl.users or {}
ucl.authed = ucl.authed or {}
function ucl.query( ply, access, hide )
	if SERVER and (not ply:IsValid() or (not hide and ply:IsListenServerHost())) then return true end
	if access == nil then return true end
	access = access:lower()
	local unique_id = ply:UniqueID()
	if CLIENT and game.SinglePlayer() then
		unique_id = "1"
	end
	if not ucl.authed[ unique_id ] then
		if CLIENT then return false end
		error( "[ULIB] Unauthed player" )
	end
	local playerInfo = ucl.authed[ unique_id ]
	if table.HasValue( playerInfo.deny, access ) then return false end
	if table.HasValue( playerInfo.allow, access ) then return true end
	if playerInfo.allow[ access ] then return true, playerInfo.allow[ access ] end
	local group = ply:GetUserGroup()
	while group do
		local groupInfo = ucl.groups[ group ]
		if not groupInfo then error( "[ULib] Player " .. ply:Nick() .. " has an invalid group (" .. group .. "), aborting. Please be careful when modifying the ULib files!" ) end
		if table.HasValue( groupInfo.allow, access ) then return true end
		if groupInfo.allow[ access ] then return true, groupInfo.allow[ access ] end
		group = ucl.groupInheritsFrom( group )
	end
	return nil
end
function ucl.groupInheritsFrom( group )
	if not ucl.groups[ group ] then return false end
	if group == ULib.ACCESS_ALL then
		return nil
	elseif not ucl.groups[ group ].inherit_from or ucl.groups[ group ].inherit_from == "" then
		return ULib.ACCESS_ALL
	else
		return ucl.groups[ group ].inherit_from
	end
end
function ucl.getInheritanceTree()
	local inherits = { [ULib.ACCESS_ALL]={} }
	local find = { [ULib.ACCESS_ALL]=inherits[ULib.ACCESS_ALL] }
	for group, _ in pairs( ucl.groups ) do
		if group ~= ULib.ACCESS_ALL then
			local inherits_from = ucl.groupInheritsFrom( group )
			if not inherits_from then inherits_from = ULib.ACCESS_ALL end
			find[ inherits_from ] = find[ inherits_from ] or {}
			find[ group ] = find[ group ] or {}
			find[ inherits_from ][ group ] = find[ group ]
		end
	end
	return inherits
end
function ucl.getGroupCanTarget( group )
	ULib.checkArg( 1, "ULib.ucl.getGroupCanTarget", "string", group )
	if not ucl.groups[ group ] then error( "Group does not exist (" .. group .. ")", 2 ) end
	return ucl.groups[ group ].can_target
end
if CLIENT then
	function ucl.initClientUCL( authed, groups )
		ucl.authed = authed
		ucl.groups = groups
		for name, data in pairs( groups ) do
			if not ULib.findInTable( {"superadmin", "admin", "user"}, name ) then
				local inherit_from = data.inherit_from or "user"
				CAMI.RegisterUsergroup( {Name=name, Inherits=inherit_from}, CAMI.ULX_TOKEN )
			end
		end
	end
end
local meta = FindMetaTable( "Player" )
if not meta then return end
function meta:query( access, hide )
	return ULib.ucl.query( self, access, hide )
end
local origIsAdmin = meta.IsAdmin
function meta:IsAdmin()
	if ucl.groups[ ULib.ACCESS_ADMIN ] then
		return self:CheckGroup( ULib.ACCESS_ADMIN )
	else
		return origIsAdmin( self )
	end
end
local origIsSuperAdmin = meta.IsSuperAdmin
function meta:IsSuperAdmin()
	if ucl.groups[ ULib.ACCESS_SUPERADMIN ] then
		return self:CheckGroup( ULib.ACCESS_SUPERADMIN )
	else
		return origIsSuperAdmin( self )
	end
end
function meta:GetUserGroup()
	if not self:IsValid() then return "" end
	local uid = self:UniqueID()
	if CLIENT and game.SinglePlayer() then
		uid = "1"
	end
	if not ucl.authed[ uid ] then return "" end
	return ucl.authed[ uid ].group or "user"
end
function meta:CheckGroup( group_check )
	if not ucl.groups[ group_check ] then return false end
	local group = self:GetUserGroup()
	while group do
		if group == group_check then return true end
		group = ucl.groupInheritsFrom( group )
	end
	return false
end