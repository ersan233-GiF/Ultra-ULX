ULib.BanMessage = [[
{{REASON}}
{{TIME_LEFT}} ]]
function ULib.getBanMessage( steamid, banData, templateMessage )
	banData = banData or ULib.bans[ steamid ]
	if not banData then return end
	templateMessage = templateMessage or ULib.BanMessage
	local replacements = {
		BANNED_BY = "(Unknown)",
		BAN_START = "(Unknown)",
		REASON = "(None given)",
		TIME_LEFT = "(Permaban)",
		STEAMID = steamid,
		STEAMID64 = util.SteamIDTo64( steamid ),
	}
	if banData.admin and banData.admin ~= "" then
		replacements.BANNED_BY = banData.admin
	end
	local time = tonumber( banData.time )
	if time and time > 0 then
		replacements.BAN_START = os.date( "%c", time )
	end
	if banData.reason and banData.reason ~= "" then
		replacements.REASON = banData.reason
	end
	local unban = tonumber( banData.unban )
	if unban and unban > 0 then
		replacements.TIME_LEFT = ULib.secondsToStringTime( unban - os.time() )
	end
  	local banMessage = templateMessage:gsub( "{{([%w_]+)}}", replacements )
	return banMessage
end
local function checkBan( steamid64, ip, password, clpassword, name )
	local steamid = util.SteamIDFrom64( steamid64 )
	local banData = ULib.bans[ steamid ]
	if not banData then return end
	if not banData.admin and not banData.reason and not banData.unban and not banData.time then return end
	local message = ULib.getBanMessage( steamid )
	Msg(string.format("%s (%s)<%s> " .. ULib.ulx_lang.T("ban_kicked_on_banlist") .. "\n", name, steamid, ip))
	return false, message
end
hook.Add( "CheckPassword", "ULibBanCheck", checkBan, HOOK_LOW )
function ULib.ban( ply, time, reason, admin )
	if not time or type( time ) ~= "number" then
		time = 0
	end
	if ply:IsListenServerHost() then
		return
	end
	ULib.addBan( ply:SteamID(), time, reason, ply:Name(), admin or ply )
end
ULib.kickban = ULib.ban
local function escapeOrNull( str )
	if not str then return "NULL"
	else return sql.SQLStr(str) end
end
local function writeBan( bandata )
	sql.Query(
		"REPLACE INTO ulib_bans (steamid, time, unban, reason, name, admin, modified_admin, modified_time) " ..
		string.format( "VALUES (%s, %i, %i, %s, %s, %s, %s, %s)",
			util.SteamIDTo64( bandata.steamID ),
			bandata.time or 0,
			bandata.unban or 0,
			escapeOrNull( bandata.reason ),
			escapeOrNull( bandata.name ),
			escapeOrNull( bandata.admin ),
			escapeOrNull( bandata.modified_admin ),
			escapeOrNull( bandata.modified_time )
		)
	)
end
function ULib.addBan( steamid, time, reason, name, admin )
	if reason == "" then reason = nil end
	local admin_name
	if admin then
		if isstring(admin) then
			admin_name = admin
		elseif not IsValid(admin) then
			admin_name = "(Console)"
		elseif admin:IsPlayer() then
			admin_name = string.format("%s(%s)", admin:Name(), admin:SteamID())
		end
	end
	local t = {}
	local timeNow = os.time()
	if ULib.bans[ steamid ] then
		t = ULib.bans[ steamid ]
		t.modified_admin = admin_name
		t.modified_time = timeNow
	else
		t.admin = admin_name
	end
	t.time = t.time or timeNow
	if time > 0 then
		t.unban = ( ( time * 60 ) + timeNow )
	else
		t.unban = 0
	end
	t.reason = reason
	t.name = name
	t.steamID = steamid
	ULib.bans[ steamid ] = t
	local strTime = time ~= 0 and ULib.secondsToStringTime( time*60 )
	local shortReason = "Banned for " .. (strTime or "eternity")
	if reason then
		shortReason = shortReason .. ": " .. reason
	end
	local longReason = shortReason
	if reason or strTime or admin then
		longReason = "\n" .. ULib.getBanMessage( steamid ) .. "\n"
	end
	local ply = player.GetBySteamID( steamid ) or player.GetBySteamID64( util.SteamIDTo64( steamid ) )
	if ply then
		ULib.kick( ply, longReason, nil, true)
	end
	game.KickID( steamid, shortReason or "" )
	writeBan( t )
	hook.Call( ULib.HOOK_USER_BANNED, _, steamid, t )
end
function ULib.unban( steamid, admin )
	RunConsoleCommand("removeid", steamid)
	RunConsoleCommand("writeid")
	ULib.bans[ steamid ] = nil
	sql.Query( "DELETE FROM ulib_bans WHERE steamid=" .. util.SteamIDTo64( steamid ) )
	hook.Call( ULib.HOOK_USER_UNBANNED, _, steamid, admin )
end
local function nilIfNull(data)
	if data == "NULL" then return nil
	else return data end
end
if not sql.TableExists( "ulib_bans" ) then
	sql.Query( "CREATE TABLE IF NOT EXISTS ulib_bans ( " ..
		"steamid INTEGER NOT NULL PRIMARY KEY, " ..
		"time INTEGER NOT NULL, " ..
		"unban INTEGER NOT NULL, " ..
		"reason TEXT, " ..
		"name TEXT, " ..
		"admin TEXT, " ..
		"modified_admin TEXT, " ..
		"modified_time INTEGER " ..
		");" )
	sql.Query( "CREATE INDEX IDX_ULIB_BANS_TIME ON ulib_bans ( time DESC );" )
	sql.Query( "CREATE INDEX IDX_ULIB_BANS_UNBAN ON ulib_bans ( unban DESC );" )
end
local LEGACY_BANS_FILE = "data/ulib/bans.txt"
function ULib.getLegacyBans()
	if not ULib.fileExists( LEGACY_BANS_FILE ) then
		return nil
	end
	local bans, err = ULib.parseKeyValues( ULib.fileRead( LEGACY_BANS_FILE ) )
	if err then
		return nil
	else
		return bans
	end
end
local legacy_bans = ULib.getLegacyBans()
function ULib.refreshBans()
	local results = sql.Query( "SELECT * FROM ulib_bans" )
	ULib.bans = {}
	if results then
		for i=1, #results do
			local r = results[i]
			r.steamID = util.SteamIDFrom64( r.steamid )
			r.steamid = nil
			r.reason = nilIfNull( r.reason )
			r.name = nilIfNull( r.name )
			r.admin = nilIfNull( r.admin )
			r.modified_admin = nilIfNull( r.modified_admin )
			r.modified_time = nilIfNull( r.modified_time )
			ULib.bans[ r.steamID ] = r
		end
	end
	if legacy_bans then
		sql.Begin()
		for steamID, bandata in pairs( legacy_bans ) do
			bandata.steamID = steamID
			if not ULib.bans[ steamID ] then
				writeBan( bandata )
				ULib.bans[ steamID ] = bandata
			end
		end
		sql.Commit()
		Msg( "[ULib] Upgraded bans storage method, moving previous bans file to " .. ULib.backupFile( LEGACY_BANS_FILE ) .. "\n" )
		ULib.fileDelete( LEGACY_BANS_FILE )
		legacy_bans = nil
	end
end
hook.Add( "Initialize", "ULibLoadBans", ULib.refreshBans, HOOK_MONITOR_HIGH )